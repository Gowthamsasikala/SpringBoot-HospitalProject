package com.appointment.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.hospital.entity.Comments;
import com.appointment.hospital.response.ResponseMessage;
import com.appointment.hospital.service.CommentsService;

@RestController
@RequestMapping(value="comments")
public class CommentsController {

	@Autowired
	private CommentsService commService;
	
	@PostMapping(value="/hospitals")
	private ResponseEntity<?> commentsHospital(@RequestBody Comments comm){
		
		try {
			return new ResponseEntity<ResponseMessage>(commService.commentsRating(comm),HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_GATEWAY);
		}
	}
	
	@GetMapping(value="getHospitalComments/{hospId}")
	private ResponseEntity<List<Comments>> getComments(@PathVariable String hospId){
			return new ResponseEntity<>(commService.getAllComments(hospId),HttpStatus.OK);
	}
	
	
}
