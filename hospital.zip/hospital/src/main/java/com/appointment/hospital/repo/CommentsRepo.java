package com.appointment.hospital.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.appointment.hospital.entity.Comments;

@Repository
public interface CommentsRepo extends JpaRepository<Comments, Long> {

	@Query("Select c from Comments c where c.hospitalId = :hospId")
	public List<Comments> getAllComm(@Param("hospId") String hospId);
	
	
	
}
