package com.appointment.hospital.service;

import java.util.List;

import com.appointment.hospital.entity.HospitalInfo;
import com.appointment.hospital.response.ResponseMessage;

public interface HospitalService {

	
	ResponseMessage hospitalinfo(HospitalInfo hosp);
	ResponseMessage updateHospital(String hospId, HospitalInfo hosp);
	ResponseMessage deleteHospital(String hospId);
	List<HospitalInfo> getAllHospitalDetails();
	HospitalInfo getByDocId(String docId);
	
}
