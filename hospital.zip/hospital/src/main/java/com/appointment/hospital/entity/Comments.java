package com.appointment.hospital.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="Comments")
public class Comments {

	@Id
	@GeneratedValue
	@Column(name="comment_id")
	private Long CommentId;
	
	@Column(name="comments")
	private String comments;
	
	@Column(name="ratings")
	private String ratings;
	
	@Column(name="hosp_id")
	private String hospitalId;
	
	public String getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	private UserRegistration users;

	public Long getCommentId() {
		return CommentId;
	}

	public void setCommentId(Long commentId) {
		CommentId = commentId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getRatings() {
		return ratings;
	}

	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	public UserRegistration getUsers() {
		return users;
	}

	public void setUsers(UserRegistration users) {
		this.users = users;
	}
	
	
	
	
	
}
