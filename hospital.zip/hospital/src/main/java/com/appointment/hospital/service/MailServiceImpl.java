package com.appointment.hospital.service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService{

	@Autowired
    private JavaMailSender javaMailSender;	
	

@Override
public void sendMail() throws MessagingException {
	MimeMessage mime = javaMailSender.createMimeMessage();
	MimeMessageHelper helper = new MimeMessageHelper(mime,true);
	helper.setFrom("gowtham.purushoth@gmail.com");
	helper.setTo("hemacsr245@gmail.com");
	helper.setSubject("User Registration for Easy-Hoppointment..");
	helper.setText("User Registration successfully done...!");

     javaMailSender.send(mime);
	
}
	
}
