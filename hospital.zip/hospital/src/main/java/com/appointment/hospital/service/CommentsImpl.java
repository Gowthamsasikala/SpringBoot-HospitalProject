package com.appointment.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appointment.hospital.entity.Comments;
import com.appointment.hospital.repo.CommentsRepo;
import com.appointment.hospital.response.ResponseMessage;

@Service
public class CommentsImpl implements CommentsService {

	@Autowired
	private CommentsRepo dao;
	
	@Override
	public ResponseMessage commentsRating(Comments comments) {
		ResponseMessage response = new ResponseMessage();
		if(comments != null) {
			Comments com = dao.saveAndFlush(comments);
			if(com != null) {
				response.setStatus("SUCCESS");
				response.setResponseMsg("Comments saved successfully..!");
				
			}
			return response;
		}else {
			response.setStatus("FAILED");
			response.setResponseMsg("Comments saved failed..!");
			return response;
		}
	}

	@Override
	public List<Comments> getAllComments(String hospId) {
		return dao.getAllComm(hospId);
	}

}
