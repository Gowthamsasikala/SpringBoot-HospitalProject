package com.appointment.hospital.service;

import javax.mail.MessagingException;

public interface MailService {

	void sendMail() throws MessagingException;
	
}
