package com.appointment.hospital.entity;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="registration")
public class UserRegistration implements UserDetails {

	@Id
	@Column(name="userId")
	private String userId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="password")
	private String passwords;

	@Column(name="confirm_password")
	private String confirmPassword;
	
	@Column(name="email")
	private String emailId;
	
	@Column(name="type_of_user")
	private String typeOfUser;
	
	@Column(name="gender")
	private String gender;
	
	@Column(name="dob")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/mm/yyyy")
	private Date dateOfBirth;
	
	@OneToMany(mappedBy="user",fetch=FetchType.LAZY)
	private List<HospitalInfo> hospital = new ArrayList<HospitalInfo>();

	@OneToMany(mappedBy="users",fetch=FetchType.LAZY)
	private List<Comments> comments = new ArrayList<>();
	
	
	public String getPasswords() {
		return passwords;
	}
   
	
	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTypeOfUser() {
		return typeOfUser;
	}

	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}

	@Override
	@JsonIgnore()
	public String getPassword() {
		
		return this.getPasswords();
	}

	@Override
	public String getUsername() {
		return this.firstName;
	}

	@Override
	@JsonIgnore()
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	@JsonIgnore()
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	@JsonIgnore()
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	
	@Override
	@JsonIgnore()
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}


	
	
	
	
}
