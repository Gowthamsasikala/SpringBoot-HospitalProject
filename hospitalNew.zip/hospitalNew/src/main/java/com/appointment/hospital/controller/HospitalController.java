package com.appointment.hospital.controller;


import java.io.File;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.appointment.hospital.entity.HospitalInfo;
import com.appointment.hospital.entity.UserRegistration;
import com.appointment.hospital.response.ResponseMessage;
import com.appointment.hospital.service.HospitalService;
import com.appointment.hospital.service.PaymentService;

@RestController
@RequestMapping(value="hospital")
public class HospitalController {

	@Autowired
	private HospitalService hospital;
	
	@Autowired
	private PaymentService payment;

	
	@PostMapping(value="/info")
	@CrossOrigin("*")
	private ResponseEntity<ResponseMessage> hospitalInfo(@RequestBody HospitalInfo hosp) {
		
		if(hosp != null) {
		   
			ResponseMessage r = hospital.hospitalinfo(hosp);
			return new ResponseEntity<ResponseMessage>(r,HttpStatus.OK);
		}else {
			ResponseMessage re =new ResponseMessage();
			return new ResponseEntity<ResponseMessage>(re,HttpStatus.OK);
		}
		
		
	}
	
	
	@PutMapping(value="/update/{hospId}")
    private ResponseEntity<?> hospitalUpdate(@PathVariable String hospId, @RequestBody HospitalInfo hosp){	
		
		if(hospId != null && hosp != null) {
			 System.out.println(hospId);
			 System.out.println(hosp.getAppointmentEndTime());
			ResponseMessage r = hospital.updateHospital(hospId, hosp);
			return new ResponseEntity<ResponseMessage>(r,HttpStatus.OK);
		}else {
			ResponseMessage re =new ResponseMessage();
			re.setStatus("FAILED");
			re.setResponseMsg("Failed to update..!");
			return new ResponseEntity<ResponseMessage>(re,HttpStatus.OK);
		}
		
	}
	
	@DeleteMapping(value="/delete/{hospId}")
	private ResponseEntity<?> deleteHospitalInfo(@PathVariable String hospId){
		if(hospId != null) {
			ResponseMessage r = hospital.deleteHospital(hospId);
			return new ResponseEntity<ResponseMessage>(r,HttpStatus.OK);
		}else {
			ResponseMessage re =new ResponseMessage();
			re.setStatus("FAILED");
			re.setResponseMsg("Failed to update..!");
			return new ResponseEntity<ResponseMessage>(re,HttpStatus.OK);
		}
	}
	
	@GetMapping(value = "/getByUserId/{docId}")
	@CrossOrigin("*")
	private ResponseEntity<?> getByDocId(@PathVariable String docId){
		if(docId != null) {
			List<HospitalInfo> r = hospital.getByDocId(docId);
			if(r != null) {
				return new ResponseEntity<List<HospitalInfo>>(r,HttpStatus.OK);
			}else {
				ResponseMessage r1 = new ResponseMessage();
				r1.setStatus("Success");
				r1.setResponseMsg("Null");
				return new ResponseEntity<ResponseMessage>(r1,HttpStatus.OK);
			}
			//System.out.println(r.getHospName());
			
		}
		return null;
	}
	
	@GetMapping(value="/getAllHosp")
	@CrossOrigin("*")
	private ResponseEntity<?> getAll(){
		try {
			System.out.println(hospital.getAllHospitalDetails());
			return new ResponseEntity<List<HospitalInfo>>(hospital.getAllHospitalDetails(),HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_GATEWAY);
		}
		
	}
	
	@GetMapping(value="getAllPatients/{hospId}/{currentDate}")
	 private ResponseEntity<?> getAllPatient(@PathVariable String hospId, @PathVariable String currentDate)
	 {
		try {
			String[] convert = currentDate.split("-");
			currentDate = convert[0]+"/"+convert[1]+"/"+convert[2];
			System.out.println(currentDate);
			List<UserRegistration> patients = payment.getAlls(hospId, currentDate);
			return new ResponseEntity<List<UserRegistration>>(patients,HttpStatus.OK); 
		}catch(Exception e) {
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_GATEWAY); 
		}
	 }
}
