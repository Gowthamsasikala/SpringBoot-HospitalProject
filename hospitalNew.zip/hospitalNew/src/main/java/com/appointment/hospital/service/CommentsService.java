package com.appointment.hospital.service;

import java.util.List;

import com.appointment.hospital.entity.Comments;
import com.appointment.hospital.response.ResponseMessage;

public interface CommentsService {

	ResponseMessage commentsRating(Comments comments);
	List<Comments> getAllComments(String hospId);
	
}
