package com.appointment.hospital.service;

import java.util.List;

import com.appointment.hospital.entity.Payment;
import com.appointment.hospital.entity.UserRegistration;
import com.appointment.hospital.response.ResponseMessage;

public interface PaymentService {

	ResponseMessage paymentInfo(Payment payment);
	
	List<UserRegistration> getAlls(String hospId,String currentDate);
}
