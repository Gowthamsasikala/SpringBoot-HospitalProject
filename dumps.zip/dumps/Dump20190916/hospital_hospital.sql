-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hospital
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hospital` (
  `hosp_id` varchar(255) NOT NULL,
  `appointment_end_time` varchar(255) DEFAULT NULL,
  `appointment_start_time` varchar(255) DEFAULT NULL,
  `consulting_fees` varchar(255) DEFAULT NULL,
  `enable_appointment` bit(1) DEFAULT NULL,
  `hosp_address` varchar(255) DEFAULT NULL,
  `hosp_description` varchar(255) DEFAULT NULL,
  `hosp_name` varchar(255) DEFAULT NULL,
  `img_url` varchar(5000) DEFAULT NULL,
  `user_user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hosp_id`),
  KEY `FKbuv462xn3n026b930m21gh4ru` (`user_user_id`),
  CONSTRAINT `FKbuv462xn3n026b930m21gh4ru` FOREIGN KEY (`user_user_id`) REFERENCES `registration` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospital`
--

LOCK TABLES `hospital` WRITE;
/*!40000 ALTER TABLE `hospital` DISABLE KEYS */;
INSERT INTO `hospital` VALUES ('Hosp-DRJ-Venk','7:00 PM','6:00 PM','1500',_binary '','preambur','Its famous for face surgery.','DRJ Hospital','drjhospital','USER-2019-Venk'),('Hosp-Gowt-Lakh','7:00 PM','10:00 AM','2000',_binary '','Guindt','Child and baby hospital','Gowtham Hospital','guindybabyhospital','USER-2019-Lakh'),('Hosp-RJ D-Nanc','10:00 PM','8:00 PM','500',_binary '','Nanganallur','Its famous for sugar patient.','RJ Diabitis','nancyandjennyhospitalimgurl','USER-2019-32'),('Hosp-Sasi-kira',NULL,NULL,'1500',_binary '','Alundur chennai','Famous Diabities ','Sasikala Diabities','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAQAAADZc7J/AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAHdElNRQfjBA0PASqSEgI7AAACy0lEQVRIx43VXWiWZRgH8N+7NW1ipavZjLnNoFqS5oFDEma42DpVY5oipqODoKBOtuM665Og6LBYXw6LosiiDDUbxKINCtTUVpZmbgW6F5U13XZ14NOz55173+1+Dp77eu7//3/d9/VxPzkzjXIrrVNvsSqcd8HvvnPEhDmM1d6WFzM8ed3uL01e6nMh/OBFGzWqMd98NRpt8pJ+IeyzNEvJZeYt9rjdXi/rR621alTjH0P6nEWTTu2GbXfweu8PGzOiHTfpMmCyYPuTBnRaiK1GjGmbTm9wwSVr0ObsjBEI4U+taHLZefWFAnuEzXjMeFF6CFftwBbhvSz9XhP2Y70rJekhXNGMg8Y1Tgm8IaxTaXBWegiDKjULr08JnHQGT2VAR0pKPCnnL8f/p9cJb+JkBrLLOyUETqBbqKUMKzFgtbsyUfleh56iBXe3VfqvMctQjXM2ZAADfjZuu90Gi0i0OIclUwJVWtLF0JXMut1jow9d8pNHPKvPZLLykEUJU52j007YdZ2/Sh2WJwX3mqsp8qhlfFlAPqMdzCvoEnLmpfPWDP4L/s2YbQlsq1G/qUsp9U4ZtSWxbs4wRhX4r0gg3wjh6VTgGSEcSqyKLKesYKOLkvenuOhA+v2Ai8InibWgMEDZtl2Rfr3T4gJUVRJEWFHQ5k5kzJ3mMnZkGMfZZiI1e+Yk8FGKn/BoDg/Y5BblOuS8qnOWu3ehYZXeMiHvY33ZpX1C+MUTapPkdfvRfpsLBJ4TPptZ+0Eh/J0UVG96tU1m+mSZy0LzFCmbxsPexzFrdfnKWJrUnCXJ7EYfWOBdvcXOV+200OMGsMExYcTziZsKe4U/3FYqRKvkhcPuSOzKdOVWh4S8+2ZLUpNhYdjuTPuU2WVIGLJmLnlerjf5C7xip21ecFoI32qYC/2ax8f9Ou0m7lA2EzRXVKTceq0acMrXeouV139gJIv/mTZx5AAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNC0xM1QxMzowMTo0MiswMjowMOXPXoIAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDQtMTNUMTM6MDE6NDIrMDI6MDCUkuY+AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAABJRU5ErkJggg==','USER-2019-kira'),('Hosp-SRM -Lakh','7:00 PM','10:00 AM','2000',_binary '','Guindt','Child and baby hospital','SRM Hospital','guindybabyhospital','USER-2019-Lakh');
/*!40000 ALTER TABLE `hospital` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-16  8:07:27
