-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hospital
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `registration` (
  `user_id` varchar(255) NOT NULL,
  `confirm_password` varchar(255) DEFAULT NULL,
  `dob` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type_of_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` VALUES ('USER-2019-32','nancy@jenny','2008-01-09 05:41:00.000000','nancy.jenny@gmail.com','Nancy','Female','Jenny','nancy@jenny','Doctor'),('USER-2019-Hema','hemaGow8056','1997-01-24 05:35:00.000000','hema.gowtham@gmail.com','Hema','Female','Malini','hemaGow8056','Patient'),('USER-2019-kira','kiran@123','1976-01-27 05:38:00.000000','kiran@gmail.com','kiran','Male','kumar','kiran@123','Doctor'),('USER-2019-Lakh','lakhsmi@21','1993-01-05 05:38:00.000000','lakhsmi.ganesh@gmail.com','Lakhsmi','Female','Ganesh','lakhsmi@21','Doctor'),('USER-2019-Manc','Mancy@123','1976-01-27 05:38:00.000000','Mancy@gmail.com','Mancy','Female','jenny','Mancy@123','Doctor'),('USER-2019-Paul','paulraj','1972-01-05 05:38:00.000000','paul.durai@gmail.com','Paul','Male','raj',NULL,'Patient'),('USER-2019-Prem','premKumar@123','1987-01-05 05:38:00.000000','prem.kumar@gmail.com','Prem','Male','Kumar','premKumar@123','Patient'),('USER-2019-Puru','purushothaman','1966-01-24 05:35:00.000000','purushothaman.gowtham@gmail.com','Purushoth','Male','Sasikala','purushothaman','Patient'),('USER-2019-Ragi','Ragini123','1992-01-05 05:38:00.000000','Ragini.durai@gmail.com','Ragini','Female','durai','Ragini123','Patient'),('USER-2019-RajK','mahli@123','1995-01-05 05:38:00.000000','mahli@gmail.com','RajKumar','Male','mahli','mahli@123','Doctor'),('USER-2019-Sari','sarika','1995-01-05 05:38:00.000000','sarika.gow@gmail.com','Sarika','Female','Gowtham','sarika','Patient'),('USER-2019-Sasi','SasikalaPuru','1970-01-23 05:32:00.000000','sasikala.purushoth@gmail.com','Sasikala','Female','P','SasikalaPuru','Patient'),('USER-2019-Srin','srini@keerthi','1996-01-27 05:38:00.000000','srinisince27@gmail.com','Srinivasan','Male','Keerthi','srini@keerthi','Patient'),('USER-2019-Venk','venkatesh','1993-01-09 05:41:00.000000','venkatesh.gowtham@gmail.com','Venkatesh','Male','jenni','venkatesh','Doctor');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-13 18:20:42
